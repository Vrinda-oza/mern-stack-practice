// var age = 25;


// if(true) {
//     console.log(age);
// }

// function solve() {
//     var age = 25;
//     console.log(age);
// }
// console.log(age);
// solve();

// var x = 10;
// var x = 20;

// {
//     let a = 10;
//     console.log(a);
// }

// let a = 20;
// a = 30;


// let a = 10;
// a = "bababr";
// a = true;
// a = null;

// const a = 28;
// console.log(a);

// const a = 20;
// console.log(a);


// let marks = 20.2345;
// marks = "Babbar";
// marks = true;


let marks = 923691643589612956198435971349858734895674398175698173971389678913768917638965718936789173598671893768917368973896718976891378917;
console.log(marks);

let mark;
console.log(typeof(mark));