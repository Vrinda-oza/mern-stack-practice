//arithmetic operator

let a = 2;
let b = 5;


// // a = a +10;
// a += 10;
// console.log(a);

// // a = a-2;
// a -= 2;
// console.log(a);


//console.log(a**b);//

//console.log('5' == 5);
//console.log('5' === 5);

// let age = 5;
// let status1 = (age > 18) ? 'I can vote' : 'I cannot Vote';


// console.log(status1);


// let ans = (true && false && true)

// let ans = (false || false || false);
// let ans = !(false);
// console.log(ans);

// console.log(false || 7 || 11 || 18);

// console.log(2 ^ 2);

//console.log(10 << 1);


// let age = 30;
// if(age >= 18 ) {
//     console.log('can vote');
// }

// let number = 5;

// if(number == 1) {
//     console.log('A');
// }
// else if(number == 2) {
//     console.log('B');
// }
// else if(number == 3) {
//     console.log('C');
// }
// else if(number == 4) {
//     console.log('D');
// }
// else {
//     console.log('F');
// }

let num = 3;

switch(num) {
    case 1: console.log('A');
    break;
    case 2: console.log('B');
    break;
    case 3: console.log('C');
    case 4: console.log('D');
    break;
    default: console.log('F');
}
