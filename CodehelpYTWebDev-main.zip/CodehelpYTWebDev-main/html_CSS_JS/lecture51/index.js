// let mydiv = document.querySelector('#mydiv');

// let newElement = document.createElement('span');
// newElement.textContent = "Love babbar"

// mydiv.insertAdjacentElement('afterend', newElement);

let parent = child.parentElement;
let child = document.querySelector('#fpara');
parent.removeChild(child);