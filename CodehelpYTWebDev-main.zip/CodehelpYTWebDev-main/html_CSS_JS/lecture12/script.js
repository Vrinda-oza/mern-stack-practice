document.addEventListener("DOMContentLoaded", function() {
    alert("Hello Jee Kaise ho saare");
  });